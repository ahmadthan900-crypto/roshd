# تطبيق رُشد - نسخة اختبار الاتصال

هذه نسخة Flutter أولية مخصصة لاختبار الوصول إلى سيرفر رُشد.

## رابط السيرفر المضبوط مسبقاً
https://kingdom-participated-softball-tanks.trycloudflare.com

ملاحظة: هذا رابط Cloudflare Quick Tunnel مؤقت. إذا أعدت تشغيل النفق فقد يتغير الرابط، وعندها حدّثه من حقل الرابط داخل التطبيق.

## إنشاء ملفات Android لأول مرة
افتح Terminal داخل هذا المجلد (android) ونفّذ:

```bash
flutter create --platforms=android .
flutter pub get
```

## تشغيل نسخة اختبار على اللابتوب
```bash
flutter run -d chrome
```

## بناء APK
```bash
flutter build apk --release
```

ستجد الملف الناتج هنا: `build/app/outputs/flutter-apk/app-release.apk`

## ما الذي تفعله هذه النسخة؟
- تعرض شاشة عربية RTL لإعداد الاتصال.
- تضع رابط النفق الحالي مسبقاً.
- ترسل طلب GET واحداً إلى مسار `/health` عند ضغط «حفظ واختبار الاتصال».
- تحفظ رابط السيرفر محلياً على الجهاز باستخدام SharedPreferences.

هذه ليست وظائف المنصة الاجتماعية والتعليمية الكاملة بعد.
