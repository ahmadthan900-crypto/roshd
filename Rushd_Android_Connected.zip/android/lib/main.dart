import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const String defaultServerUrl =
    'https://kingdom-participated-softball-tanks.trycloudflare.com';

void main() => runApp(const RushdApp());

class RushdApp extends StatelessWidget {
  const RushdApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF4ADE80);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'رُشد',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D1117),
        colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.dark),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF161B22),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: ConnectionPage()),
    );
  }
}

class ConnectionPage extends StatefulWidget {
  const ConnectionPage({super.key});
  @override
  State<ConnectionPage> createState() => _ConnectionPageState();
}

class _ConnectionPageState extends State<ConnectionPage> {
  final controller = TextEditingController();
  bool busy = false;
  String message = 'أدخل رابط النفق الذي يظهر على حاسوب السيرفر.';
  bool? connected;

  @override
  void initState() {
    super.initState();
    _loadUrl();
  }

  Future<void> _loadUrl() async {
    final prefs = await SharedPreferences.getInstance();
    controller.text = prefs.getString('server_url') ?? defaultServerUrl;
    if (mounted) setState(() {});
  }

  String get baseUrl => controller.text.trim().replaceFirst(RegExp(r'/+$'), '');

  Future<void> _testConnection() async {
    if (baseUrl.isEmpty || !baseUrl.startsWith('https://') && !baseUrl.startsWith('http://')) {
      setState(() { connected = false; message = 'أدخل رابطاً صحيحاً يبدأ بـ https://'; });
      return;
    }
    setState(() { busy = true; message = 'جارٍ الاتصال بالسيرفر...'; });
    try {
      final response = await http.get(Uri.parse('$baseUrl/health')).timeout(const Duration(seconds: 15));
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('server_url', baseUrl);
      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['status'] == 'healthy') {
        setState(() { connected = true; message = 'تم الاتصال بسيرفر رُشد بنجاح.'; });
      } else {
        setState(() { connected = false; message = 'وصلنا إلى العنوان، لكن استجابة السيرفر غير متوقعة.'; });
      }
    } catch (_) {
      setState(() { connected = false; message = 'تعذر الاتصال. تأكد أن السيرفر والنفق يعملان وأن الرابط صحيح.'; });
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رُشد'), centerTitle: true),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Icon(Icons.school_rounded, size: 76, color: Color(0xFF4ADE80)),
              const SizedBox(height: 14),
              const Text('مرحباً بك في رُشد', textAlign: TextAlign.center, style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('إعداد الاتصال بالسيرفر', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 28),
              TextField(
                controller: controller,
                keyboardType: TextInputType.url,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'رابط السيرفر / Tunnel URL', hintText: 'https://xxxx.trycloudflare.com', prefixIcon: Icon(Icons.link)),
              ),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: busy ? null : _testConnection,
                icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.wifi_tethering),
                label: Text(busy ? 'جارٍ الاختبار...' : 'حفظ واختبار الاتصال'),
              ),
              const SizedBox(height: 18),
              Card(color: const Color(0xFF161B22), child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(connected == true ? Icons.check_circle : connected == false ? Icons.error : Icons.info_outline, color: connected == true ? const Color(0xFF4ADE80) : connected == false ? Colors.orange : Colors.white70),
                  const SizedBox(width: 10),
                  Expanded(child: Text(message)),
                ]),
              )),
              const SizedBox(height: 16),
              const Text('ملاحظة: يجب أن يبقى حاسوب السيرفر مشغّلاً، مع نافذتي السيرفر والنفق مفتوحتين.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, height: 1.6)),
            ]),
          ),
        ),
      ),
    );
  }
}
